//___FILEHEADER___

import UIKit

class ___FILEBASENAMEASIDENTIFIER___: ___VARIABLE_cocoaTouchSubclass___ {
    
    // MARK: - Public Property
    

    // MARK: - Private Property


    // MARK: - Init
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupViews()
        layoutViews()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK:- 初始化UI
    func setupViews() {
        
    }
    
    // MARK:- 布局
    func layoutViews() {
        
    }
    
    // MARK: - Target Mehtods
    
}

// MARK: - Public Method
extension ___FILEBASENAMEASIDENTIFIER___ {
    
}

// MARK: - Private Method
extension ___FILEBASENAMEASIDENTIFIER___ {
    
}
