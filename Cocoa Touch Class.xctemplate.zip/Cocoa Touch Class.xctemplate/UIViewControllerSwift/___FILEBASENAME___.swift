//___FILEHEADER___

import UIKit

class ___FILEBASENAMEASIDENTIFIER___: ___VARIABLE_cocoaTouchSubclass___ {
    // MARK: - Public Property
    
    // MARK: - Private Property 

    // MARK: - LifeCycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupViews()
        layoutViews()
        loadData()
    }
    
    // MARK: - SetupUI
    func setupViews() {
        
    }
    
    // MARK: - LayoutUI
    func layoutViews() {
        
    }
    
    // MARK: - LoadData
    func loadData() {
        
    }
    
    // MARK: - Target Mehtods
    
}

// MARK: - Public Method
extension ___FILEBASENAMEASIDENTIFIER___ {
    
}

// MARK: - Private Method
extension ___FILEBASENAMEASIDENTIFIER___ {
    
}

